xgo --docker-image mysteriumnetwork/xgo:1.17.3  -targets=linux/amd64  .

zip -r fish.zip LoginFish-linux-amd64 static/ data/