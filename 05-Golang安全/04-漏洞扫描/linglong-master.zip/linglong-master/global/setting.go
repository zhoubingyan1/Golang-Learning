package global

import "linglong/pkg/setting"

var (
	ServerSetting *setting.ServerSettingS
	AppSetting      *setting.AppSettingS
	DatabaseSetting *setting.DatabaseSettingS
	MasscanSetting *setting.MasscanSettingS
)
