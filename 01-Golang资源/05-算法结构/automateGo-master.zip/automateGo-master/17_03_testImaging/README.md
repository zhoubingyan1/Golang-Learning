## Реализация на Go проектов части II
### Глава 17 "Работа с изображениями"
Тестовое github.com/disintegration/imaging 