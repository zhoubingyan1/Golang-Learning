## Реализация на Go проектов части II
### Глава 16 "Отправка сообщений электронной почты и текстовых сообщений"
Учебный проект на странице 481  
twilio SMS test  
SMS to Russia  
SMS cannot be sent to landline destination number. The Twilio REST API will throw a 400 response with error code 21614, the message will not appear in the logs and the account will not be charged.