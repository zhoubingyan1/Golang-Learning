## Реализация на Go проектов части II
### Глава 16 "Отправка сообщений электронной почты и текстовых сообщений"
Тестовое IMAP  

Необходимы:  
"github.com/emersion/go-imap"  
"github.com/emersion/go-imap/client"  
"github.com/emersion/go-sasl"