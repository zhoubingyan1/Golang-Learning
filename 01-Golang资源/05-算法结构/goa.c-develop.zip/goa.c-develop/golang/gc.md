# 垃圾回收GC

https://www.cnblogs.com/linguoguo/p/10611657.html

https://studygolang.com/articles/18850?fr=sidebar

https://www.cnblogs.com/saryli/p/10105393.html

https://my.oschina.net/renhc/blog/2244717