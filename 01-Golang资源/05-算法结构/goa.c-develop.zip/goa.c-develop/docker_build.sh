#!/bin/bash
docker build -t hunterhug/algorithm:latest .