package main

// import "fmt"

func main() {
	test(11)
}

func test(i int) {
	var a [10]int
	a[i] = 111
}
