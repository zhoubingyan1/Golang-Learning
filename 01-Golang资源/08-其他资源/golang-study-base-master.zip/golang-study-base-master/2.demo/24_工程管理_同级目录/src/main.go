package main

func main() {
	test()
}
