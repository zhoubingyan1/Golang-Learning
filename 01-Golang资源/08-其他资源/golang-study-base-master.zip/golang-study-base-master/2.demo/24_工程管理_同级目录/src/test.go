package main

import (
	"fmt"
)

func test() {
	fmt.Println("this is test page")
}
