package test

import "fmt"

type Stu struct { // 首字母大写
	Id   int // 首字母大写
	Name string
}

func Test() { // 首字母大写
	fmt.Println("this is test")
}
